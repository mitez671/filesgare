/* مشق‌بازی — سرور
   فقط با Node.js (نسخه‌ی ۱۸ یا بالاتر) اجرا می‌شود و هیچ بسته‌ی اضافه‌ای لازم ندارد (مناسب ترموکس و هر هاست).
   اجرا:  node server.js
*/
'use strict';
require('./lib/compat.js');
/* روی هاست‌های اشتراکی خطای شروع معمولاً دیده نمی‌شود و فقط ۵۰۳ برمی‌گردد؛
   پس هر خطای شروع در data/startup-error.log هم نوشته می‌شود. */
const STARTUP_LOG = require('path').join(__dirname, 'data', 'startup-error.log');
function fatal(e) {
  const msg = `[${new Date().toISOString()}] Node ${process.version}\n${(e && e.stack) || e}\n\n`;
  console.error(msg);
  try { require('fs').mkdirSync(require('path').dirname(STARTUP_LOG), { recursive: true }); require('fs').appendFileSync(STARTUP_LOG, msg); } catch (x) {}
}
process.on('uncaughtException', e => { fatal(e); process.exit(1); });
process.on('unhandledRejection', e => fatal(e));
if (+process.versions.node.split('.')[0] < 16) fatal(new Error('نسخه‌ی Node خیلی قدیمی است (' + process.version + '). در پنل هاست نسخه‌ی ۱۸ یا بالاتر را انتخاب کنید.'));
const http = require('http');
const fs = require('fs');
const fsp = fs.promises;
const path = require('path');
const zlib = require('zlib');
const crypto = require('crypto');
const { URL } = require('url');
const CATALOG = require('./public/js/catalog5.js'); // پایه‌ی اول + چهارم + ششم
const TTS = require('./tts.js');
const SMS = require('./lib/sms.js');
const SEO = require('./lib/seo.js');
const Match = require('./lib/match.js');
const QB = require('./lib/qbank.js');
const Net = require('./lib/net.js');
const School = require('./lib/school.js');
const Audit = require('./lib/audit.js');
const SHOP = require('./public/js/shop.js'); // فروشگاه ستاره (۱.۱۰.۰)؛ قیمت‌ها فقط همین‌جا
const FAM = require('./public/js/family.js'); // ۱.۲۰.۰: قول بابا و مامان، حیوون من، بلندخوانی
const ADV = require('./public/js/adv_core.js'); // ۱.۲۱.۰: جزیره من، داستان فانوس دریایی، مأموریت روزانه

/* ---------- تنظیمات ---------- */
const ROOT = __dirname;
const PUBLIC = path.join(ROOT, 'public');
const DATA = path.join(ROOT, 'data');
const MEDIA = path.join(DATA, 'media');            // صداها و عکس‌های ضبط‌شده
fs.mkdirSync(path.join(MEDIA, 'voice'), { recursive: true });
fs.mkdirSync(path.join(MEDIA, 'img'), { recursive: true });

const bool = (v, d) => (v == null || v === '' ? d : String(v) === 'true');
function loadConfig() {
  const file = path.join(ROOT, 'config.json');
  let c = {};
  if (fs.existsSync(file)) c = JSON.parse(fs.readFileSync(file, 'utf8'));
  const env = process.env, z = c.zarinpal || {}, s = c.sms || {};
  const publicUrl = (env.PUBLIC_URL || c.publicUrl || '').replace(/\/$/, '');
  return {
    /* بعضی هاست‌ها (Passenger، iisnode) به‌جای عدد، مسیر سوکت می‌دهند */
    port: /^\d+$/.test(String(env.PORT || '')) ? +env.PORT : (env.PORT || c.port || 3000),
    host: env.HOST || c.host || '0.0.0.0',
    publicUrl,                                                     // مثلا https://mashghbazi.ir
    adminKey: env.ADMIN_KEY || c.adminKey || '',
    priceToman: +(env.PRICE_TOMAN || c.priceToman || 49000),       // قیمت ارزیابی کامل
    zarinpal: { merchantId: env.ZARINPAL_MERCHANT || z.merchantId || '', sandbox: bool(env.ZARINPAL_SANDBOX != null ? env.ZARINPAL_SANDBOX : z.sandbox, false) },
    /* پرداخت آزمایشی فقط وقتی سایت هنوز آدرس عمومی ندارد (روی گوشی یا شبکه‌ی خانه) */
    devPayments: bool(env.DEV_PAYMENTS != null ? env.DEV_PAYMENTS : c.devPayments, !publicUrl),
    /* ارزیابی کامل (پولی). تا وقتی false است در رابط نمایش داده نمی‌شود و مسیرهای پرداخت و گزارش کامل بسته‌اند. */
    fullReport: bool(env.FULL_REPORT != null ? env.FULL_REPORT : c.fullReport, false),
    /* تحلیل با هوش مصنوعی (هر سرویس سازگار با OpenAI). خالی باشد تحلیل خودکار قاعده‌محور نشان داده می‌شود. */
    /* TWA (برنامه‌ی اندروید برای بازار/مایکت): نام بسته و اثر انگشت SHA-256 کلید امضا. بدون اینها assetlinks.json ساخته نمی‌شود. */
    twa: { package: env.TWA_PACKAGE || (c.twa && c.twa.package) || 'ir.mashghbazi.app', sha256: String(env.TWA_SHA256 || (c.twa && [].concat(c.twa.sha256 || []).join(',')) || '').split(',').map(s => s.trim().toUpperCase()).filter(Boolean) },
    contact: env.CONTACT || c.contact || '',                      /* متن تماس در صفحه‌ی حریم خصوصی، مثلاً ایمیل */
    allowedOrigins: [].concat(c.allowedOrigins || []),
    ai: { baseUrl: env.AI_BASE_URL || (c.ai && c.ai.baseUrl) || '', apiKey: env.AI_API_KEY || (c.ai && c.ai.apiKey) || '', model: env.AI_MODEL || (c.ai && c.ai.model) || '', dailyMax: +(env.AI_DAILY_MAX || (c.ai && c.ai.dailyMax) || 300) },
    secureCookie: bool(env.SECURE_COOKIE != null ? env.SECURE_COOKIE : c.secureCookie, /^https:/i.test(publicUrl)),   /* با آدرس https خودکار روشن می‌شود */
    proxyHops: Math.max(1, +(env.PROXY_HOPS || c.proxyHops || 1)),     /* تعداد پراکسی‌های مورد اعتماد (Apache=1، Cloudflare+Apache=2) */
    originCheck: bool(env.ORIGIN_CHECK != null ? env.ORIGIN_CHECK : c.originCheck, true),
    /* پشت nginx این را true کنید تا آی‌پی واقعی کاربر از X-Forwarded-For خوانده شود */
    trustProxy: bool(env.TRUST_PROXY != null ? env.TRUST_PROXY : c.trustProxy, false),
    sms: Object.assign({}, s, { provider: env.SMS_PROVIDER || s.provider || '', apiKey: env.SMS_API_KEY || s.apiKey || '', template: env.SMS_TEMPLATE || s.template || '', username: env.SMS_USERNAME || s.username || '', password: env.SMS_PASSWORD || s.password || '', sender: env.SMS_SENDER || s.sender || '' }),
    /* tts.eleven: صدای ElevenLabs. کلید را در config.json (tts.eleven.apiKey) یا متغیر ELEVEN_API_KEY بگذارید؛ شناسه‌ی صدا پیش‌فرض دارد.
       maxChars: سقف نویسه‌ی هر بار ساخت خودکار در استودیو (۰ = بدون سقف) تا اعتبار حساب ناخواسته تمام نشود. */
    tts: Object.assign({ voice: 'dilara', pitch: '+8Hz', rate: '-6%', gecVersion: '' }, c.tts || {}, {
      eleven: Object.assign({ voiceId: 'DaaZHsvMDARmTB28Vd5Z', model: 'eleven_v3', format: 'mp3_44100_64', maxChars: 9000 }, (c.tts && c.tts.eleven) || {},
        env.ELEVEN_API_KEY ? { apiKey: env.ELEVEN_API_KEY } : {}, env.ELEVEN_VOICE_ID ? { voiceId: env.ELEVEN_VOICE_ID } : {}) })
  };
}
const CFG = loadConfig();
const WEAK_KEYS = ['', 'baba1405', 'change-me', 'CHANGE-ME', 'admin', '1234', '123456'];
if (WEAK_KEYS.includes(CFG.adminKey) || CFG.adminKey.length < 10 || /^CHANGE/i.test(CFG.adminKey)) {
  CFG.adminKey = crypto.randomBytes(8).toString('hex');
  console.log('⚠️  adminKey در config.json تنظیم نشده یا خیلی ساده است (دست‌کم ۱۰ نویسه). کلید موقت استودیو تا خاموش شدن سرور: ' + CFG.adminKey);
}
SMS.init(CFG.sms);

/* ---------- پایگاه داده‌ی ساده (فایل JSON) ---------- */
const DB_FILE = path.join(DATA, 'db.json');
let db = { users: {}, sessions: {}, attempts: {}, state: {}, payments: {}, classes: {} };
/* اگر db.json خراب باشد با دیتابیس خالی ادامه نمی‌دهیم: اول از آخرین پشتیبان سالم برمی‌گردیم، وگرنه سرور با پیام روشن متوقف می‌شود */
function loadDb() {
  if (!fs.existsSync(DB_FILE) || fs.statSync(DB_FILE).size === 0) return;
  try { db = Object.assign(db, JSON.parse(fs.readFileSync(DB_FILE, 'utf8'))); return; }
  catch (e) { console.error('⚠️ db.json خراب است: ' + e.message); }
  const broken = DB_FILE + '.broken-' + Date.now(); fs.copyFileSync(DB_FILE, broken); console.error('نسخه‌ی خراب نگه داشته شد: ' + broken);
  const bd = path.join(DATA, 'backups'); let days = []; try { days = fs.readdirSync(bd).filter(x => /^\d{4}-\d\d-\d\d$/.test(x)).sort().reverse(); } catch (x) {}
  for (const d of days) {
    try { const j = JSON.parse(fs.readFileSync(path.join(bd, d, 'db.json'), 'utf8')); db = Object.assign(db, j); console.error('✅ از پشتیبان ' + d + ' بازیابی شد (تغییرهای بعد از آن از دست رفته‌اند).'); fs.writeFileSync(DB_FILE, JSON.stringify(db)); return; } catch (x) {}
  }
  console.error('❌ پشتیبان سالمی پیدا نشد. سرور برای جلوگیری از پاک شدن داده‌ها متوقف شد. فایل خراب را تعمیر کنید یا یک پشتیبان را به data/db.json برگردانید.');
  process.exit(1);
}
loadDb();
/* مهاجرت: نشست‌های قدیمی با توکن خام → هش */
for (const k of Object.keys(db.sessions || {})) { if (k.length !== 64) { db.sessions[crypto.createHash('sha256').update(k).digest('hex')] = db.sessions[k]; delete db.sessions[k]; } }
/* مهاجرت حساب‌های نسخه‌ی قبل (اسم مستعار + رمز ۴ رقمی) */
const firstOkStars = uid => (db.attempts[uid] || []).filter(a => a.first && a.ok).length;
for (const u of Object.values(db.users)) {
  if (u.pin && !u.pass) { u.pass = u.pin; delete u.pin; }
  if (u.stars == null) u.stars = firstOkStars(u.id);
  if (u.rating == null) u.rating = 1000;
  if (!QB.GRADES.includes(u.grade)) u.grade = QB.GRADES[0];
  if (db.state[u.id]) delete db.state[u.id].stars;
}
const byMobile = new Map(Object.values(db.users).filter(u => u.mobile).map(u => [u.mobile, u.id]));

let saveTimer = null, saving = false, dirty = false;
function persist() { dirty = true; clearTimeout(saveTimer); saveTimer = setTimeout(flushDb, 800); }
async function flushDb() {
  if (saving) { saveTimer = setTimeout(flushDb, 300); return; }
  if (!dirty) return;
  saving = true; dirty = false;
  try { const tmp = DB_FILE + '.tmp'; await fsp.writeFile(tmp, JSON.stringify(db)); await fsp.rename(tmp, DB_FILE); }
  catch (e) { console.error('ذخیره‌ی db.json انجام نشد:', e.message); dirty = true; }
  finally { saving = false; }
}
/* ---------- پشتیبان‌گیری روزانه ---------- */
const BACKUP_DIR = path.join(DATA, 'backups'), BACKUP_KEEP = 14, BACKUP_FILES = ['db.json', 'visits.json', 'alerts.json'];
function backupDay() { const d = new Date(); return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0'); }
function listBackups() { try { return fs.readdirSync(BACKUP_DIR).filter(x => /^\d{4}-\d\d-\d\d$/.test(x)).sort(); } catch (e) { return []; } }
function backupNow(force) {
  const day = backupDay(), dir = path.join(BACKUP_DIR, day);
  if (!force && fs.existsSync(dir)) return false;
  if (!fs.existsSync(DB_FILE)) return false;          /* هنوز چیزی ذخیره نشده */
  try {
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, 'db.json'), JSON.stringify(Object.assign({}, db, { sessions: {} })));   /* بدون نشست‌ها */
    BACKUP_FILES.forEach(n => { const src = path.join(DATA, n); if (n !== 'db.json' && fs.existsSync(src)) fs.copyFileSync(src, path.join(dir, n)); });
    const all = listBackups(); while (all.length > BACKUP_KEEP) { const old = path.join(BACKUP_DIR, all.shift()); try { fs.readdirSync(old).forEach(f => fs.unlinkSync(path.join(old, f))); fs.rmdirSync(old); } catch (e) {} }
    return true;
  } catch (e) { console.error('پشتیبان‌گیری انجام نشد:', e.message); return false; }
}
function saveNow() { clearTimeout(saveTimer); fs.writeFileSync(DB_FILE, JSON.stringify(db)); Audit.saveNow(); }
process.on('SIGINT', () => { saveNow(); process.exit(0); });
process.on('SIGTERM', () => { saveNow(); process.exit(0); });

/* پاک کردن سشن‌های منقضی */
function sweepSessions() { const now = Date.now(); let n = 0; for (const t in db.sessions) if (db.sessions[t].exp < now || !db.users[db.sessions[t].uid]) { delete db.sessions[t]; n++; } if (n) persist(); }
sweepSessions(); setInterval(sweepSessions, 3600 * 1000).unref();
setTimeout(() => backupNow(false), 15000).unref(); setInterval(() => backupNow(false), 3600 * 1000).unref();   /* هر روز یک نسخه، ۱۴ روز آخر */

Match.init(db, persist, QB.C.MASCOTS);
Audit.init(DATA);

/* ---------- ابزارها ---------- */
const MIME = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.webmanifest': 'application/manifest+json; charset=utf-8', '.txt': 'text/plain; charset=utf-8', '.xml': 'application/xml; charset=utf-8',
  '.woff2': 'font/woff2', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp',
  '.webm': 'audio/webm', '.ogg': 'audio/ogg', '.mp3': 'audio/mpeg', '.m4a': 'audio/mp4', '.mp4': 'audio/mp4', '.wav': 'audio/wav', '.aac': 'audio/aac', '.ico': 'image/x-icon', '.wasm': 'application/wasm', '.pck': 'application/octet-stream' };
const COMPRESSIBLE = new Set(['.html', '.js', '.css', '.json', '.svg', '.txt', '.xml', '.webmanifest']);
const SEC_HEADERS = { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'X-Frame-Options': 'SAMEORIGIN' };

function send(res, code, body, headers) {
  res.writeHead(code, Object.assign({ 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' }, headers || {}));
  res.end(typeof body === 'string' || Buffer.isBuffer(body) ? body : JSON.stringify(body));
}
/* پاسخ متنی فشرده (gzip/brotli) با ETag تا فایل تکراری دوباره دانلود نشود */
const zCache = new Map();
function sendText(req, res, code, buf, type, extra) {
  const etag = '"' + crypto.createHash('sha1').update(buf).digest('hex').slice(0, 24) + '"';
  const h = Object.assign({ 'Content-Type': type, ETag: etag, Vary: 'Accept-Encoding', 'Cache-Control': 'no-cache' }, SEC_HEADERS, extra || {});
  if (code === 200 && req.headers['if-none-match'] === etag) { res.writeHead(304, h); return res.end(); }
  const ae = String(req.headers['accept-encoding'] || ''), enc = /\bbr\b/.test(ae) ? 'br' : /\bgzip\b/.test(ae) ? 'gzip' : '';
  let body = buf;
  if (enc && buf.length > 1024) {
    const key = enc + etag; body = zCache.get(key);
    if (!body) {
      body = enc === 'br' ? zlib.brotliCompressSync(buf, { params: { [zlib.constants.BROTLI_PARAM_QUALITY]: 9 } }) : zlib.gzipSync(buf, { level: 9 });
      if (zCache.size > 200) zCache.clear(); zCache.set(key, body);
    }
    h['Content-Encoding'] = enc;
  }
  h['Content-Length'] = body.length;
  res.writeHead(code, h); res.end(req.method === 'HEAD' ? undefined : body);
}
function readBody(req, limit) {
  return new Promise((resolve, reject) => {
    const chunks = []; let size = 0;
    req.on('data', c => { size += c.length; if (size > limit) { reject(Object.assign(new Error('too large'), { code: 413 })); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks)));
    req.on('error', reject);
  });
}
async function readJson(req) {
  if (!/^application\/json\b/i.test(String(req.headers['content-type'] || ''))) throw Object.assign(new Error('need json'), { code: 415 });
  const b = await readBody(req, 512 * 1024);
  try { const j = JSON.parse(b.toString('utf8') || '{}'); return j && typeof j === 'object' ? j : {}; } catch (e) { throw Object.assign(new Error('bad json'), { code: 400 }); }
}
const safeDecode = s => { try { return decodeURIComponent(s); } catch (e) { return null; } };
function cookies(req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach(p => { const i = p.indexOf('='); if (i > 0) { const v = safeDecode(p.slice(i + 1).trim()); if (v != null) out[p.slice(0, i).trim()] = v; } });
  return out;
}
const toEn = s => String(s == null ? '' : s).replace(/[۰-۹]/g, d => '۰۱۲۳۴۵۶۷۸۹'.indexOf(d)).replace(/[٠-٩]/g, d => '٠١٢٣٤٥٦٧٨٩'.indexOf(d));
/* scrypt غیرهم‌زمان با سقف هم‌زمانی (حلقه‌ی اصلی Node قفل نمی‌شود؛ صف پر شد «شلوغ است») */
let scryptRun = 0; const scryptWait = [];
function scryptSlot() { return new Promise((res, rej) => { const go = () => { scryptRun++; res(); }; if (scryptRun < 3) return go(); if (scryptWait.length >= 60) return rej(Object.assign(new Error('busy'), { code: 503 })); scryptWait.push(go); }); }
function scryptDone() { scryptRun--; const n = scryptWait.shift(); if (n) n(); }
async function hashPass(p, salt) {
  await scryptSlot();
  try { return await new Promise((res, rej) => crypto.scrypt(String(p), salt, 32, (e, k) => (e ? rej(e) : res(k.toString('hex'))))); } finally { scryptDone(); }
}
async function passOk(u, p) { const a = Buffer.from(await hashPass(toEn(p), u.salt), 'hex'), b = Buffer.from(u.pass || '', 'hex'); return a.length === b.length && crypto.timingSafeEqual(a, b); }
function newId(n) { return crypto.randomBytes(n || 12).toString('hex'); }
function clientIp(req) {
  if (CFG.trustProxy) {
    /* پراکسی آی‌پی واقعی را به «انتهای» X-Forwarded-For اضافه می‌کند؛ مقدارهای اول را خود کاربر می‌تواند جعل کند */
    const parts = String(req.headers['x-forwarded-for'] || '').split(',').map(x => x.trim()).filter(Boolean);
    if (parts.length) return String(parts[Math.max(0, parts.length - CFG.proxyHops)]).slice(0, 60);
    if (req.headers['x-real-ip']) return String(req.headers['x-real-ip']).slice(0, 60);
  }
  return req.socket.remoteAddress || '';
}
/* نشست‌ها در دیتابیس فقط به‌صورت هش نگه داشته می‌شوند؛ اگر فایل یا پشتیبان لو رفت توکن قابل‌استفاده نیست */
const tokKey = t => crypto.createHash('sha256').update(String(t)).digest('hex');
function originOk(req) {
  let o; try { o = new URL(String(req.headers.origin)).host.toLowerCase(); } catch (e) { return false; }
  const ok = new Set([String(req.headers.host || '').toLowerCase(), String(req.headers['x-forwarded-host'] || '').split(',')[0].trim().toLowerCase()]);
  if (CFG.publicUrl) { try { ok.add(new URL(CFG.publicUrl).host.toLowerCase()); } catch (e) {} }
  (CFG.allowedOrigins || []).forEach(x => ok.add(String(x).toLowerCase()));
  return ok.has(o);
}
function currentUser(req) {
  const t = cookies(req).mb_session, k = t && tokKey(t);
  const s = k && Object.prototype.hasOwnProperty.call(db.sessions, k) && db.sessions[k];
  if (!s || s.exp < Date.now()) return null;
  return db.users[s.uid] || null;
}
const COOKIE = (v, age) => `mb_session=${v}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${age}${CFG.secureCookie ? '; Secure' : ''}`;
const SESSION_MS = 1000 * 60 * 60 * 24 * 90;    /* ۹۰ روز؛ با هر باز شدن برنامه (حداکثر هفته‌ای یک بار) تمدید می‌شود */
function startSession(res, uid) {
  const token = newId(24);
  db.sessions[tokKey(token)] = { uid, exp: Date.now() + SESSION_MS, at: Date.now() };
  persist();
  res.setHeader('Set-Cookie', COOKIE(token, SESSION_MS / 1000));
}
function endSessions(uid, keep) { const kk = keep ? tokKey(keep) : ''; for (const t in db.sessions) if (db.sessions[t].uid === uid && t !== kk) delete db.sessions[t]; persist(); }
function publicUser(u) {
  return u ? { id: u.id, nick: u.nick, mascot: u.mascot, grade: u.grade, paid: !!u.paid, created: u.created, stars: u.stars || 0, rating: u.rating || 1000, mobile: SMS.mask(u.mobile), hasMobile: !!u.mobile } : null;
}
function baseUrl(req) {
  if (CFG.publicUrl) return CFG.publicUrl;
  const proto = CFG.trustProxy && req.headers['x-forwarded-proto'] === 'https' ? 'https' : 'http';
  const host = String(req.headers.host || 'localhost').replace(/[^a-zA-Z0-9.:\-\[\]]/g, '');
  return proto + '://' + host;
}

/* محدودیت تلاش (پنجره‌ی لغزان) */
const buckets = new Map();
function hits(name, key, win) { const k = name + '|' + key, now = Date.now(), t = (buckets.get(k) || []).filter(x => now - x < win); buckets.set(k, t); return t; }
const limited = (name, key, max, win) => { const r = hits(name, key, win).length >= max; if (r && !/^(att|pw)$/.test(name) || (r && name === 'pw')) Audit.log('rate_limited', { detail: name + ':' + String(key).slice(0, 24) }); return r; };
const note = (name, key, win) => hits(name, key, win).push(Date.now());
setInterval(() => { const now = Date.now(); for (const [k, t] of buckets) if (!t.length || now - t[t.length - 1] > 86400000) buckets.delete(k); }, 600000).unref();

/* ---------- گزارش‌ها ---------- */
const gradeOfGame = gid => { const g = CATALOG.GAMES[gid]; return g ? (CATALOG.BOOKS[g.book].grade || 1) : 0; };
function summarize(uid, grade) {
  const list = db.attempts[uid] || [];
  const firsts = list.filter(a => a.first && (!grade || gradeOfGame(a.g) === grade));
  const byBook = {}, byGame = {}, bySkill = {}, days = new Set();
  let ms = 0;
  for (const a of firsts) {
    const g = CATALOG.GAMES[a.g]; if (!g) continue;
    const add = (o, k) => { o[k] = o[k] || { ok: 0, n: 0, ms: 0, items: {}, early: { ok: 0, n: 0 }, late: { ok: 0, n: 0 } }; return o[k]; };
    for (const bucket of [add(byBook, g.book), add(byGame, a.g), add(bySkill, g.skill)]) {
      bucket.n++; if (a.ok) bucket.ok++; bucket.ms += Math.min(a.ms || 0, 120000);
      if (!a.ok && a.item) bucket.items[a.item] = (bucket.items[a.item] || 0) + 1;
    }
    days.add(new Date(a.t || 0).toISOString().slice(0, 10));
    ms += Math.min(a.ms || 0, 120000);
  }
  const perSkill = {};
  firsts.forEach(a => { const g = CATALOG.GAMES[a.g]; if (g) (perSkill[g.skill] = perSkill[g.skill] || []).push(a); });
  for (const k in perSkill) {
    const arr = perSkill[k], half = Math.floor(arr.length / 2);
    arr.forEach((a, i) => { const b = i < half ? bySkill[k].early : bySkill[k].late; b.n++; if (a.ok) b.ok++; });
  }
  return { total: firsts.length, ok: firsts.filter(a => a.ok).length, byBook, byGame, bySkill, days: [...days].sort(), minutes: Math.round(ms / 60000) };
}

/* ---------- کد کلاس (۱.۱۹.۰) ---------- */
function classesOf(u) {
  const all = Object.values(db.classes || {});
  const own = all.filter(c => c.owner === u.id).map(c => ({ code: c.code, name: c.name, grade: c.grade, count: c.members.length }));
  const j = all.find(c => c.members.includes(u.id)), owner = j && db.users[j.owner];
  return { own, joined: j ? { code: j.code, name: j.name, teacher: owner ? owner.nick : '' } : null };
}
function classReport(c) {
  const day = 864e5, now = Date.now();
  const rows = c.members.filter(id => db.users[id]).map(id => {
    const u = db.users[id], s = summarize(id, u.grade), st = db.state[id] || {}, at = db.attempts[id] || [], last = at.length ? at[at.length - 1].t || 0 : 0;
    const week = at.filter(a => a.first && now - (a.t || 0) < 7 * day).length;
    const books = Object.keys(s.byBook).map(b => ({ b, name: CATALOG.BOOKS[b].name, pct: Math.round(100 * s.byBook[b].ok / s.byBook[b].n), n: s.byBook[b].n })).filter(x => x.n >= 5).sort((a, b) => a.pct - b.pct);
    return { id, nick: u.nick, grade: u.grade, stars: u.stars || 0, answers: s.total, pct: s.total ? Math.round(100 * s.ok / s.total) : null, week, days: s.days.length,
      lastDays: last ? Math.floor((now - last) / day) : null, weak: books.length && books[0].pct < 70 ? books[0].name : '' };
  }).sort((a, b) => b.week - a.week);
  return { code: c.code, name: c.name, grade: c.grade, rows };
}
function level(p) { return p >= 85 ? 'عالی' : p >= 65 ? 'خوب' : p >= 45 ? 'در حال یادگیری' : 'نیاز به تمرین بیشتر'; }
function skillsOfGrade(g) { const s = new Set(); Object.values(CATALOG.GAMES).forEach(x => { if ((CATALOG.BOOKS[x.book].grade || 1) === g) s.add(x.skill); }); return [...s]; }

function basicReport(u) {
  const s = summarize(u.id, u.grade), st = db.state[u.id] || {};
  const books = QB.BOOKS_OF(u.grade).map(id => {
    const b = s.byBook[id] || { ok: 0, n: 0 }, bk = CATALOG.BOOKS[id];
    return { id, grade: bk.grade || 1, name: bk.full || bk.name, ok: b.ok, n: b.n, pct: b.n ? Math.round(100 * b.ok / b.n) : null };
  });
  return { nick: u.nick, grade: u.grade, stars: u.stars || 0, gamesPlayed: Object.keys(st.plays || {}).filter(g => gradeOfGame(g) === u.grade).length, totalAnswers: s.total,
    pct: s.total ? Math.round(100 * s.ok / s.total) : null, books, daysActive: s.days.length, paid: !!u.paid, priceToman: CFG.priceToman,
    skillNames: skillsOfGrade(u.grade).slice(0, 6).map(k => CATALOG.SKILLS[k].name) };
}
function fullReport(u) {
  const s = summarize(u.id, u.grade);
  const skills = Object.keys(s.bySkill).map(k => {
    const b = s.bySkill[k], pct = Math.round(100 * b.ok / b.n);
    const e = b.early.n ? Math.round(100 * b.early.ok / b.early.n) : null, l = b.late.n ? Math.round(100 * b.late.ok / b.late.n) : null;
    const missed = Object.entries(b.items).sort((x, y) => y[1] - x[1]).slice(0, 5).map(x => x[0]);
    return { id: k, name: CATALOG.SKILLS[k].name, pct, n: b.n, level: level(pct), avgSec: Math.round(b.ms / b.n / 100) / 10,
      trend: e != null && l != null && b.n >= 6 ? l - e : null, missed, tip: CATALOG.SKILLS[k].tip };
  }).sort((a, b) => a.pct - b.pct);
  const games = Object.keys(s.byGame).map(k => ({ id: k, title: CATALOG.GAMES[k].title, book: CATALOG.BOOKS[CATALOG.GAMES[k].book].full || CATALOG.BOOKS[CATALOG.GAMES[k].book].name,
    pct: Math.round(100 * s.byGame[k].ok / s.byGame[k].n), n: s.byGame[k].n }));
  return { nick: u.nick, grade: u.grade, generated: new Date().toISOString(), totalAnswers: s.total, pct: s.total ? Math.round(100 * s.ok / s.total) : null,
    minutes: s.minutes, days: s.days, skills, games,
    strengths: skills.filter(x => x.pct >= 80 && x.n >= 5).map(x => x.name),
    focus: skills.filter(x => x.pct < 65 && x.n >= 3).map(x => x.name) };
}
function profile(u) {
  const ms = u.mstats || { win: 0, draw: 0, loss: 0, streak: 0, best: 0 };
  return { user: publicUser(u), mstats: ms, matches: (u.matchLog || []).slice(0, 20).map(m => ({ at: m.at, opp: m.opp, my: m.my, their: m.their, result: m.result, delta: m.delta, reward: m.reward, ok: m.myOk, n: m.n })),
    smsEnabled: SMS.enabled() };
}

/* ---------- زرین‌پال ---------- */
async function zarinpalRequest(amountRial, description, callback) {
  const host = CFG.zarinpal.sandbox ? 'https://sandbox.zarinpal.com' : 'https://payment.zarinpal.com';
  const j = await Net.request(host + '/pg/v4/payment/request.json', { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ merchant_id: CFG.zarinpal.merchantId, amount: amountRial, description, callback_url: callback }) });
  if (!j.data || j.data.code !== 100) throw new Error('zarinpal request failed: ' + JSON.stringify(j.errors || j));
  return { authority: j.data.authority, url: host + '/pg/StartPay/' + j.data.authority };
}
async function zarinpalVerify(amountRial, authority) {
  const host = CFG.zarinpal.sandbox ? 'https://sandbox.zarinpal.com' : 'https://payment.zarinpal.com';
  const j = await Net.request(host + '/pg/v4/payment/verify.json', { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
    body: JSON.stringify({ merchant_id: CFG.zarinpal.merchantId, amount: amountRial, authority }) });
  return j.data && (j.data.code === 100 || j.data.code === 101) ? { ok: true, ref: j.data.ref_id } : { ok: false, err: j.errors };
}
function markPaid(pay, ref) {
  pay.status = 'paid'; pay.ref = String(ref || ''); pay.paidAt = Date.now();
  Audit.log('pay_ok', { uid: pay.uid, nick: (db.users[pay.uid] || {}).nick, detail: Math.round(pay.amountRial / 10) + ' تومان' });
  const u = db.users[pay.uid]; if (u) { u.paid = true; u.paidAt = pay.paidAt; }
  persist();
}
const payMode = () => (!CFG.fullReport ? 'off' : CFG.zarinpal.merchantId ? 'zarinpal' : CFG.devPayments ? 'dev' : 'off');

/* ---------- رسانه‌ها (صدا و عکس ضبط‌شده) ---------- */
function mediaManifest() {
  const list = dir => { const out = {}; try { fs.readdirSync(path.join(MEDIA, dir)).forEach(f => { const id = f.replace(/\.[^.]+$/, ''); const st = fs.statSync(path.join(MEDIA, dir, f)); out[id] = `/media/${dir}/${f}?v=${Math.round(st.mtimeMs)}`; }); } catch (e) {} return out; };
  return { voices: list('voice'), images: list('img'), eleven: Object.keys(SRC).filter(k => SRC[k] === 1).reduce((o, k) => { o[k] = 1; return o; }, {}) };
}
const SAFE_ID = /^[a-z0-9_]{1,64}$/;
function removeOld(dir, id) { try { fs.readdirSync(path.join(MEDIA, dir)).forEach(f => { if (f.replace(/\.[^.]+$/, '') === id) fs.unlinkSync(path.join(MEDIA, dir, f)); }); } catch (e) {} }

/* منبع هر صدا: ۱ = ساخته‌شده با ElevenLabs، ۲ = فایلی که خودتان در استودیو ضبط/آپلود کرده‌اید (هرگز جایگزین نمی‌شود).
   صدایی که در این فهرست نیست و mp3 است، صدای خودکارِ قبلی (Edge) حساب می‌شود و ساخت ElevenLabs آن را جایگزین می‌کند. */
const SRC_FILE = path.join(DATA, 'media', 'eleven-made.json');
let SRC = {}; try { SRC = JSON.parse(fs.readFileSync(SRC_FILE, 'utf8')) || {}; } catch (e) { SRC = {}; }
const saveSrc = () => { try { fs.writeFileSync(SRC_FILE, JSON.stringify(SRC)); } catch (e) { console.error('voice source list:', e.message); } };

const GRADE_W = { 'اول': 1, 'دوم': 2, 'سوم': 3, 'چهارم': 4, 'پنجم': 5, 'ششم': 6 };
const phraseGrade = g => { const m = String(g).match(/(اول|دوم|سوم|چهارم|پنجم|ششم)/); return m ? GRADE_W[m[1]] : 0; };   // ۰ = جمله‌های عمومی بازی‌ها
const STORY_GROUP = 'قصه‌ی فانوس دریایی';
/* ترتیب ساخت صدا (۱.۲۱.۱): ۱) جمله‌های عمومی بازی‌ها ۲) قصه‌ی فانوس دریایی ۳) «درس اول» همه‌ی کتاب‌ها، بعد درس دوم همه‌ی کتاب‌ها، …
   اگر کلاسِ اولویت‌دار (want = ۱ تا ۶) داده شود، ردیف ۳ فقط برای کتاب‌های همان کلاس است و بقیه‌ی کلاس‌ها بعد از آن می‌آیند. */
function elevenPlan(want) {
  want = +want || 0;
  const ph = QB.C.phrases().filter(p => p.group !== 'قرآن');
  const GEN = ['تشویق', 'دلگرمی', 'پایان بازی', 'سلام هم‌بازی‌ها', 'راهنمای بازی‌ها', 'بگرد و پیدا کن', 'دست بزن، بشمار', 'زیر آب یا روی آب', 'با کدام حس', 'صدای آ یا ب', 'سالم باش', STORY_GROUP];
  const books = [], seenG = {};
  ph.forEach((p, i) => { p.order = i; const b = String(p.group).split('·')[0].trim(); p.gen = GEN.indexOf(b) >= 0 ? 1 : 0; p.r = 0; p.bi = 0;
    if (p.gen) { p.tier = b === STORY_GROUP ? 1 : 0; p.gr = 0; return; }
    p.gr = phraseGrade(b) || 1; p.tier = (!want || p.gr === want) ? 2 : 3;
    if (books.indexOf(b) < 0) books.push(b); seenG[b] = seenG[b] || []; if (seenG[b].indexOf(p.group) < 0) seenG[b].push(p.group); p.r = seenG[b].indexOf(p.group); p.bi = books.indexOf(b); });
  ph.sort((a, b) => (a.tier - b.tier) || (a.r - b.r) || (a.bi - b.bi) || (a.order - b.order));
  const ext = {}; try { fs.readdirSync(path.join(MEDIA, 'voice')).forEach(f => { ext[f.replace(/\.[^.]+$/, '')] = path.extname(f).toLowerCase(); }); } catch (e) {}
  const need = p => { const x = ext[p.id]; return !x || (x === '.mp3' && !SRC[p.id]); };
  const todo = ph.filter(need);
  const max = +CFG.tts.eleven.maxChars || 0; let chars = 0; const pick = [];
  for (const p of todo) { if (max && chars + p.text.length > max) break; pick.push(p); chars += p.text.length; }
  /* گزارش هر دسته: چند جمله، چند تا صدا (هر نوعی) دارند، چند تا هنوز بی‌صدا یا صدای ماشینی قدیمی */
  const names = ['جمله‌های عمومی بازی‌ها', STORY_GROUP], tiers = names.map(n => ({ name: n, total: 0, voiced: 0, todo: 0 }));
  for (let g = 1; g <= 6; g++) tiers.push({ name: 'کلاس ' + ['اول', 'دوم', 'سوم', 'چهارم', 'پنجم', 'ششم'][g - 1], total: 0, voiced: 0, todo: 0, grade: g });
  ph.forEach(p => { const t = p.gen ? tiers[p.tier] : tiers[1 + p.gr]; t.total++; if (ext[p.id]) t.voiced++; if (need(p)) t.todo++; });
  return { pick, willBuild: pick.length, willChars: chars, todo: todo.length, todoChars: todo.reduce((a, p) => a + p.text.length, 0), maxChars: max, want, tiers,
    elevenDone: ph.filter(p => SRC[p.id] === 1 && ext[p.id]).length, kept: ph.filter(p => ext[p.id] && (ext[p.id] !== '.mp3' || SRC[p.id] === 2)).length, all: ph.length };
}
const ELV = { running: false, stop: false, total: 0, ok: 0, fail: 0, chars: 0, error: '', startedAt: 0, endedAt: 0 };
async function elevenRun(pick) {
  Object.assign(ELV, { running: true, stop: false, total: pick.length, ok: 0, fail: 0, chars: 0, error: '', startedAt: Date.now(), endedAt: 0 });
  let streak = 0;
  try {
    for (const p of pick) {
      if (ELV.stop) { ELV.error = ELV.error || 'متوقف شد.'; break; }
      try {
        const audio = await TTS.synth(p.text, Object.assign({}, CFG.tts, { voice: 'eleven' }));
        removeOld('voice', p.id); fs.writeFileSync(path.join(MEDIA, 'voice', p.id + '.mp3'), audio);
        SRC[p.id] = 1; ELV.ok++; ELV.chars += p.text.length; streak = 0; if (ELV.ok % 10 === 0) saveSrc();
      } catch (e) {
        ELV.fail++; streak++; ELV.error = e.message; console.error('ElevenLabs:', e.message);
        if (e.fatal || streak >= 3) break;                    // کلید/اعتبار/شناسه‌ی غلط: ادامه بی‌فایده است
      }
      await new Promise(r => setTimeout(r, 150));
    }
  } finally { saveSrc(); ELV.running = false; ELV.endedAt = Date.now(); }
}

/* ---------- اعتبارسنجی ---------- */
const NICK_RE = /^[\p{L}\p{N}\p{M} _\-‌.]{2,20}$/u;
function cleanNick(s) { return String(s || '').replace(/[<>"'`]/g, '').trim().replace(/\s+/g, ' '); }
function checkPassword(p) { p = toEn(p); return p.length >= 6 && p.length <= 64 ? '' : 'رمز باید دست‌کم ۶ نویسه باشد.'; }
const validGrade = g => QB.GRADES.includes(+g);

/* ---------- مسیرها ---------- */
async function api(req, res, url) {
  const p = url.pathname, m = req.method, ip = clientIp(req);
  const me = currentUser(req);
  const A = (type, d) => { d = d || {}; const uid = d.uid || (me && me.id) || '', nick = d.nick || (me && me.nick) || ''; Audit.log(type, { ip, ua: req.headers['user-agent'] || '', uid, nick, detail: d.detail || '' }); if (uid && (type === 'login_ok' || type === 'register' || type === 'reset')) Audit.seen(uid, ip, nick); };
  if (me && p === '/api/me' && m === 'GET') {
    Audit.seen(me.id, ip, me.nick);
    const tk = cookies(req).mb_session, ss = tk && db.sessions[tokKey(tk)];
    if (ss && Date.now() - (ss.at || 0) > 7 * 864e5) { ss.at = Date.now(); ss.exp = Date.now() + SESSION_MS; res.setHeader('Set-Cookie', COOKIE(tk, SESSION_MS / 1000)); persist(); }
  }

  if (p === '/api/me' && m === 'GET') return send(res, 200, { user: publicUser(me), priceToman: CFG.priceToman, payMode: payMode(), fullReport: CFG.fullReport, sms: SMS.enabled(), grades: QB.GRADES });

  if (p === '/api/otp' && m === 'POST') {
    const b = await readJson(req), mobile = SMS.normMobile(b.mobile), purpose = b.purpose === 'reset' ? 'reset' : b.purpose === 'mobile' ? 'mobile' : 'register';
    if (!mobile) return send(res, 400, { error: 'شماره موبایل درست نیست. مثل ۰۹۱۲۳۴۵۶۷۸۹ بنویسید.' });
    A('otp_send', { detail: purpose + ' ' + SMS.mask(mobile) });
    const exists = byMobile.has(mobile);
    if (purpose !== 'reset' && exists) return send(res, 409, { error: 'با این شماره قبلاً ثبت‌نام شده. وارد شوید یا رمز را بازیابی کنید.' });
    if (purpose === 'reset' && !exists) return send(res, 200, { ok: true });          // وجود حساب را لو نمی‌دهیم
    try { const r = await SMS.send(mobile, purpose, ip); return send(res, r.ok ? 200 : 429, r); }
    catch (e) { console.error('SMS:', e.message); SMS.logErr(e); return send(res, 502, { error: 'ارسال پیامک انجام نشد. کمی بعد دوباره امتحان کنید.' }); }
  }

  if (p === '/api/ev' && m === 'POST') {
    if (limited('ev', ip, 300, 3600000)) return send(res, 429, { ok: false });
    note('ev', ip, 3600000);
    const b = await readJson(req).catch(() => ({}));
    Audit.event(String((b && b.n) || ''), ip, req.headers['user-agent']);
    return send(res, 200, { ok: true });
  }
  if (p === '/api/register' && m === 'POST') {
    if (limited('reg', ip, 15, 3600000)) return send(res, 429, { error: 'از این اینترنت ثبت‌نام زیادی انجام شده. کمی بعد امتحان کنید.' });
    const b = await readJson(req);
    const nick = cleanNick(b.nick), mobile = SMS.normMobile(b.mobile), pass = toEn(b.password), grade = +b.grade;
    if (!mobile) return send(res, 400, { error: 'شماره موبایل پدر یا مادر را درست بنویسید (مثل ۰۹۱۲۳۴۵۶۷۸۹).', field: 'mobile' });
    if (!NICK_RE.test(nick)) return send(res, 400, { error: 'اسم مستعار باید بین ۲ تا ۲۰ حرف باشد.', field: 'nick' });
    if (!validGrade(grade)) return send(res, 400, { error: 'کلاس را انتخاب کنید.', field: 'grade' });
    const pe = checkPassword(pass); if (pe) return send(res, 400, { error: pe, field: 'password' });
    if (byMobile.has(mobile)) return send(res, 409, { error: 'با این شماره قبلاً ثبت‌نام شده. وارد شوید.', field: 'mobile' });
    if (SMS.enabled() && !SMS.check(mobile, 'register', toEn(b.otp))) return send(res, 400, { error: 'کد پیامک درست نیست یا منقضی شده.', field: 'otp' });
    note('reg', ip, 3600000); Audit.event('signup', ip, req.headers['user-agent']);
    const salt = newId(8), id = newId(8);
    byMobile.set(mobile, id);                       /* رزرو شماره پیش از هش (جلوگیری از ثبت‌نام هم‌زمان با یک شماره) */
    let PASSHASH; try { PASSHASH = await hashPass(pass, salt); } catch (e) { byMobile.delete(mobile); throw e; }
    const u = db.users[id] = { id, nick, mobile, mobileVerified: SMS.enabled(), salt, pass: PASSHASH, mascot: String(b.mascot || 'rabbit').replace(/[^a-z]/g, '').slice(0, 20) || 'rabbit',
      grade, created: Date.now(), paid: false, stars: 0, rating: 1000 };
    /* پیشرفتِ دوران مهمانی (فقط بازی‌های همین کلاس) منتقل می‌شود */
    if (Array.isArray(b.attempts)) db.attempts[id] = vetAttempts([], b.attempts.slice(-3000).map(a => cleanAttempt(a, grade)).filter(Boolean));
    u.stars = firstOkStars(id);
    if (b.state && typeof b.state === 'object') db.state[id] = cleanState(b.state);
    /* ۱.۲۰.۰: هدفِ پدر و مادر و نامه‌هایی که در دوران مهمانی روی همین گوشی گذاشته شده */
    if (b.fam && typeof b.fam === 'object') { u.fam = FAM.clean(b.fam); if (u.fam.goal) u.fam.goal.base = Math.min(u.fam.goal.base, FAM.metrics(db.state[id], u.stars)[u.fam.goal.kind]); }
    A('register', { uid: id, nick, detail: 'کلاس ' + grade });
    startSession(res, id); persist();
    return send(res, 200, { user: publicUser(u), state: stateOf(u) });
  }

  if (p === '/api/login' && m === 'POST') {
    if (limited('login-all', ip, 80, 600000)) return send(res, 429, { error: 'تلاش زیاد بود. ده دقیقه‌ی دیگر دوباره امتحان کن.' });
    note('login-all', ip, 600000);
    if (limited('login-ip', ip, 30, 600000)) return send(res, 429, { error: 'تلاش زیاد بود. ده دقیقه‌ی دیگر دوباره امتحان کن.' });
    const b = await readJson(req);
    const raw = String(b.id || b.nick || '').trim(), mobile = SMS.normMobile(raw);
    const acct = mobile || cleanNick(raw).toLowerCase();
    if (limited('login-acct', acct, 8, 900000)) return send(res, 429, { error: 'برای این حساب چند بار رمز اشتباه زده شد. پانزده دقیقه‌ی دیگر امتحان کنید.' });
    const u = mobile ? db.users[byMobile.get(mobile)] : Object.values(db.users).find(x => !x.mobile && x.nick.toLowerCase() === acct);
    if (!u || !(await passOk(u, b.password != null ? b.password : b.pin))) { A('login_fail', { detail: mobile ? SMS.mask(mobile) : acct.slice(0, 20) }); note('login-ip', ip, 600000); note('login-acct', acct, 900000); return send(res, 401, { error: 'شماره موبایل یا رمز درست نیست.' }); }
    A('login_ok', { uid: u.id, nick: u.nick });
    startSession(res, u.id);
    /* تمرین‌های دوران مهمانیِ همین گوشی */
    if (Array.isArray(b.attempts) && b.attempts.length) addAttempts(u, b.attempts.slice(-3000));
    return send(res, 200, { user: publicUser(u), state: stateOf(u) });
  }

  if (p === '/api/reset' && m === 'POST') {
    if (!SMS.enabled()) return send(res, 400, { error: 'بازیابی رمز با پیامک روی این سرور فعال نیست. با پشتیبانی تماس بگیرید.' });
    const b = await readJson(req), mobile = SMS.normMobile(b.mobile), pass = toEn(b.password);
    const pe = checkPassword(pass); if (pe) return send(res, 400, { error: pe });
    const u = mobile && db.users[byMobile.get(mobile)];
    if (!u || !SMS.check(mobile, 'reset', toEn(b.otp))) return send(res, 400, { error: 'کد پیامک درست نیست یا منقضی شده.' });
    u.salt = newId(8); u.pass = await hashPass(pass, u.salt); u.mobileVerified = true;
    A('reset', { uid: u.id, nick: u.nick });
    endSessions(u.id); startSession(res, u.id);
    return send(res, 200, { user: publicUser(u), state: stateOf(u) });
  }

  if (p === '/api/logout' && m === 'POST') {
    A('logout');
    const t = cookies(req).mb_session, kk = t && tokKey(t); if (kk && db.sessions[kk]) { delete db.sessions[kk]; persist(); }
    res.setHeader('Set-Cookie', COOKIE('', 0));
    return send(res, 200, { ok: true });
  }

  if (p === '/api/media' && m === 'GET') return send(res, 200, mediaManifest(), { 'Cache-Control': 'no-cache' });

  /* ---------- مسابقه ---------- */
  if (p.startsWith('/api/match')) try {
    if (!me) return send(res, 401, { error: 'برای مسابقه باید ثبت‌نام کنی یا وارد شوی.' });
    if (p === '/api/match/info' && m === 'GET') return send(res, 200, { grade: me.grade, today: School.describe().text, books: Match.info(me.grade), online: Match.onlineCount(me.grade), n: Match.N_Q });
    if (p === '/api/match/current' && m === 'GET') { const cm = Match.current(me.id); return send(res, 200, { match: cm ? Match.view(cm, me.id) : null }); }
    if (p === '/api/match/find' && m === 'POST') {
      if (limited('match', me.id, 40, 3600000)) return send(res, 429, { error: 'امروز خیلی مسابقه دادی! کمی استراحت کن و بعد برگرد.' });
      const cm = Match.current(me.id); if (!cm) { note('match', me.id, 3600000); A('match_start'); }
      return send(res, 200, { match: Match.view(Match.find(me), me.id) });
    }
    if (p === '/api/match/cancel' && m === 'POST') return send(res, 200, { ok: Match.cancel(me.id) });
    const mm = p.match(/^\/api\/match\/([a-f0-9]{18})(\/answer)?$/);
    if (mm) {
      const match = Match.live.get(mm[1]);
      if (!match || !match.players.some(x => x.uid === me.id)) return send(res, 404, { error: 'این مسابقه پیدا نشد.' });
      if (!mm[2] && m === 'GET') return send(res, 200, { match: Match.view(match, me.id) });
      if (mm[2] && m === 'POST') { const b = await readJson(req); const r = Match.answer(match, me.id, +b.i, b.choice == null ? -1 : +b.choice); return send(res, r.error ? 409 : 200, Object.assign(r, { match: Match.view(match, me.id) })); }
    }
    return send(res, 404, { error: 'not found' });
  } catch (e) {
    if (e.code === 503) return send(res, 503, { error: 'سرور شلوغ است؛ چند ثانیه بعد دوباره امتحان کنید.' });
    if ([400, 413, 415].includes(e.code)) throw e;
    console.error('match api', p, e);
    return send(res, 500, { error: 'مسابقه الان کمی مشکل دارد. چند ثانیه بعد دوباره امتحان کن.' });
  }

  // از اینجا به بعد ورود لازم است
  if (p === '/api/me' && m === 'DELETE') {
    if (!me) return send(res, 401, { error: 'برای این کار باید وارد شوی.' });
    const b = await readJson(req);
    if (!(await passOk(me, b.password))) return send(res, 401, { error: 'رمز درست نیست.' });
    A('delete_account');
    endSessions(me.id); if (me.mobile) byMobile.delete(me.mobile);
    delete db.users[me.id]; delete db.attempts[me.id]; delete db.state[me.id]; if (db.ai) delete db.ai[me.id];
    Object.keys(db.payments || {}).forEach(k => { if (db.payments[k].uid === me.id) db.payments[k].uid = 'deleted'; });   /* سابقه‌ی مالی می‌ماند، بدون هویت */
    Audit.forget(me.id); persist();
    res.setHeader('Set-Cookie', COOKIE('', 0));
    return send(res, 200, { ok: true });
  }
  if (p.startsWith('/api/me/')) {
    if (!me) return send(res, 401, { error: 'برای این کار باید وارد شوی.' });
    if (p === '/api/me/state' && m === 'GET') return send(res, 200, { state: stateOf(me) });
    if (p === '/api/me/chest' && m === 'POST') {
      /* صندوق گنج روزانه: بعد از هدف امروز (دست‌کم CHEST_MIN جواب درست امروز به وقت تهران)، روزی یک بار CHEST_STARS ستاره */
      const today = tehranDay(Date.now());
      if (me.chest === today) return send(res, 200, { ok: true, already: true, stars: me.stars || 0, chest: today });
      const n = (db.attempts[me.id] || []).filter(a => a.ok && tehranDay(a.t) === today).length;
      if (n < CHEST_MIN) return send(res, 409, { error: 'اول هدف امروز رو بگیر!', need: CHEST_MIN - n });
      me.chest = today; me.stars = (me.stars || 0) + CHEST_STARS; persist(); A('chest');
      return send(res, 200, { ok: true, stars: me.stars, bonus: CHEST_STARS, chest: today });
    }
    if (p === '/api/me/shop' && m === 'POST') {
      if (limited('shop', me.id, 30, 60000)) return send(res, 429, { error: 'too many' });
      note('shop', me.id, 60000);
      const b = await readJson(req), r = shopBuy(me, b.item); if (r.code === 200 && !r.body.already) A('shop_buy', { detail: String(b.item) });
      return send(res, r.code, r.body);
    }
    /* ۱.۲۰.۰: هدف و جایزه‌ی پدر و مادر و پیام تشویقی (همه‌ی قاعده‌ها در public/js/family.js) */
    if (p === '/api/me/family' && m === 'POST') {
      if (limited('fam', me.id, 30, 60000)) return send(res, 429, { error: 'too many' });
      note('fam', me.id, 60000);
      const b = await readJson(req), r = FAM.apply(me.fam, String(b.op || ''), b, FAM.metrics(db.state[me.id], me.stars), Date.now());
      if (r.error) return send(res, 400, { error: r.error, fam: famOf(me) });
      me.fam = r.fam; persist(); if (['goal', 'given', 'cheer'].indexOf(b.op) >= 0) A('family_' + b.op);
      return send(res, 200, { ok: true, fam: famOf(me) });
    }
    if (p === '/api/me/state' && m === 'PUT') { const b = await readJson(req); db.state[me.id] = cleanState(b.state || {}); persist(); return send(res, 200, { ok: true, stars: me.stars || 0 }); }
    if (p === '/api/me/attempts' && m === 'POST') {
      const b = await readJson(req);
      if (limited('att', me.id, 40, 60000)) return send(res, 429, { error: 'too many' });
      note('att', me.id, 60000);
      const saved = addAttempts(me, (Array.isArray(b.attempts) ? b.attempts : []).slice(0, 500));
      return send(res, 200, { ok: true, saved, stars: me.stars || 0 });
    }
    if (p === '/api/me/profile' && m === 'GET') return send(res, 200, profile(me));
    if (p === '/api/me/profile' && m === 'PUT') {
      const b = await readJson(req);
      if (b.nick != null) { const n = cleanNick(b.nick); if (!NICK_RE.test(n)) return send(res, 400, { error: 'اسم مستعار باید بین ۲ تا ۲۰ حرف باشد.' }); me.nick = n; }
      if (b.grade != null) { if (!validGrade(b.grade)) return send(res, 400, { error: 'این کلاس وجود ندارد.' }); if (Match.current(me.id)) return send(res, 409, { error: 'وسط مسابقه نمی‌شود کلاس را عوض کرد.' }); me.grade = +b.grade; }
      if (b.mascot != null) me.mascot = String(b.mascot).replace(/[^a-z]/g, '').slice(0, 20) || me.mascot;
      A('profile_update', { detail: 'کلاس ' + me.grade });
      persist(); return send(res, 200, profile(me));
    }
    if (p === '/api/me/password' && m === 'PUT') {
      const b = await readJson(req);
      if (limited('pw', me.id, 6, 900000)) return send(res, 429, { error: 'تلاش زیاد بود. کمی بعد امتحان کنید.' });
      if (!(await passOk(me, b.old))) { note('pw', me.id, 900000); return send(res, 401, { error: 'رمز فعلی درست نیست.' }); }
      const pe = checkPassword(b.password); if (pe) return send(res, 400, { error: pe });
      me.salt = newId(8); me.pass = await hashPass(toEn(b.password), me.salt);
      A('pw_change');
      endSessions(me.id, cookies(req).mb_session);
      return send(res, 200, { ok: true });
    }
    if (p === '/api/me/mobile' && m === 'PUT') {
      const b = await readJson(req), mobile = SMS.normMobile(b.mobile);
      if (!mobile) return send(res, 400, { error: 'شماره موبایل درست نیست.' });
      if (byMobile.has(mobile) && byMobile.get(mobile) !== me.id) return send(res, 409, { error: 'این شماره برای حساب دیگری است.' });
      if (!(await passOk(me, b.password))) return send(res, 401, { error: 'رمز درست نیست.' });
      if (SMS.enabled() && !SMS.check(mobile, 'mobile', toEn(b.otp))) return send(res, 400, { error: 'کد پیامک درست نیست یا منقضی شده.' });
      if (me.mobile) byMobile.delete(me.mobile);
      me.mobile = mobile; me.mobileVerified = SMS.enabled(); byMobile.set(mobile, me.id); persist(); A('mobile_change', { detail: SMS.mask(mobile) });
      return send(res, 200, profile(me));
    }
    /* ---------- ۱.۱۹.۰: کد کلاس. هر کاربرِ واردشده می‌تواند کلاس بسازد (معلم) یا با کد به کلاسی بپیوندد (دانش‌آموز). ---------- */
    if (p === '/api/me/class/mine' && m === 'GET') return send(res, 200, classesOf(me));
    if (p === '/api/me/class/create' && m === 'POST') {
      if (limited('class', me.id, 10, 60000)) return send(res, 429, { error: 'too many' }); note('class', me.id, 60000);
      const b = await readJson(req), name = String(b.name || '').replace(/[<>]/g, '').trim().slice(0, 30);
      if (name.length < 2) return send(res, 400, { error: 'اسم کلاس را بنویس (حداقل ۲ حرف).' });
      db.classes = db.classes || {}; if (Object.values(db.classes).filter(c => c.owner === me.id).length >= 8) return send(res, 409, { error: 'حداکثر ۸ کلاس می‌شود ساخت.' });
      let code; do { code = Array.from({ length: 5 }, () => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[crypto.randomBytes(1)[0] % 32]).join(''); } while (db.classes[code]);
      db.classes[code] = { code, name, owner: me.id, grade: me.grade, members: [], created: Date.now() }; A('class_create'); persist();
      return send(res, 200, classesOf(me));
    }
    if (p === '/api/me/class/join' && m === 'POST') {
      if (limited('classjoin', me.id, 10, 60000)) return send(res, 429, { error: 'too many' }); note('classjoin', me.id, 60000);
      const b = await readJson(req), code = String(b.code || '').toUpperCase().replace(/[^A-Z0-9]/g, ''), c = (db.classes || {})[code];
      if (!c) return send(res, 404, { error: 'کلاسی با این کد پیدا نشد. کد را دوباره بررسی کن.' });
      if (c.owner === me.id) return send(res, 409, { error: 'این کلاسِ خودت است.' });
      for (const o of Object.values(db.classes)) o.members = o.members.filter(id => id !== me.id);
      if (c.members.length >= 60) return send(res, 409, { error: 'این کلاس پر است.' });
      c.members.push(me.id); A('class_join'); persist(); return send(res, 200, classesOf(me));
    }
    if (p === '/api/me/class/leave' && m === 'POST') { for (const o of Object.values(db.classes || {})) o.members = o.members.filter(id => id !== me.id); persist(); return send(res, 200, classesOf(me)); }
    { const mm = p.match(/^\/api\/me\/class\/([A-Z0-9]{5})(\/report|\/remove)?$/);
      if (mm) {
        const c = (db.classes || {})[mm[1]]; if (!c || c.owner !== me.id) return send(res, 404, { error: 'کلاس پیدا نشد.' });
        if (mm[2] === '/report' && m === 'GET') return send(res, 200, classReport(c));
        if (mm[2] === '/remove' && m === 'POST') { const b = await readJson(req); c.members = c.members.filter(id => id !== b.id); persist(); return send(res, 200, classReport(c)); }
        if (!mm[2] && m === 'DELETE') { delete db.classes[c.code]; persist(); return send(res, 200, classesOf(me)); }
      } }
    if (p === '/api/me/report' && m === 'GET') return send(res, 200, basicReport(me));
    if (p === '/api/me/report/ai' && m === 'GET') {
      const rep = fullReport(me), AI = require('./lib/ai.js');
      if (rep.totalAnswers < 10) return send(res, 200, { notEnough: true, need: 10, have: rep.totalAnswers });
      db.ai = db.ai || {}; const day = new Date().toISOString().slice(0, 10), c = db.ai[me.id];
      /* همان تحلیل تا وقتی ۱۰ جواب تازه نیامده یا یک هفته نگذشته نگه داشته می‌شود */
      if (c && c.result && rep.totalAnswers - c.answers < 10 && Date.now() - c.at < 7 * 864e5) return send(res, 200, Object.assign({ at: c.at }, c.result));
      db.aiDay = db.aiDay && db.aiDay.day === day ? db.aiDay : { day, n: 0 };
      const useAI = AI.enabled(CFG.ai) && db.aiDay.n < CFG.ai.dailyMax && !limited('ai', me.id, 3, 86400000);
      if (useAI) { db.aiDay.n++; note('ai', me.id, 86400000); }
      const result = useAI ? await AI.analyze(CFG.ai, rep) : AI.rules(rep);
      if (result.source === 'ai' || c == null) { db.ai[me.id] = { at: Date.now(), answers: rep.totalAnswers, result }; persist(); }
      return send(res, 200, Object.assign({ at: Date.now() }, result));
    }
    if (p === '/api/me/report/full' && m === 'GET') {
      if (!CFG.fullReport) return send(res, 404, { error: 'ارزیابی کامل فعلاً در دسترس نیست.' });
      if (!me.paid) return send(res, 402, { error: 'ارزیابی کامل بعد از پرداخت باز می‌شود.', priceToman: CFG.priceToman });
      return send(res, 200, fullReport(me));
    }
    if (p === '/api/me/pay' && m === 'POST') {
      if (!CFG.fullReport) return send(res, 404, { error: 'ارزیابی کامل فعلاً در دسترس نیست.' });
      if (me.paid) return send(res, 200, { already: true });
      A('pay_start');
      const mode = payMode();
      if (mode === 'off') return send(res, 409, { error: 'پرداخت هنوز روی این سایت فعال نشده است.' });
      const pid = newId(8), amountRial = CFG.priceToman * 10;
      const pay = db.payments[pid] = { id: pid, uid: me.id, amountRial, status: 'new', created: Date.now() };
      if (mode === 'dev') { persist(); return send(res, 200, { url: '/pay/dev?pid=' + pid, mode }); }
      try {
        const z = await zarinpalRequest(amountRial, 'ارزیابی کامل مشق‌بازی — ' + me.nick, baseUrl(req) + '/pay/callback?pid=' + pid);
        pay.authority = z.authority; persist();
        return send(res, 200, { url: z.url, mode });
      } catch (e) { console.error(e); return send(res, 502, { error: 'اتصال به درگاه پرداخت برقرار نشد. کمی بعد دوباره امتحان کنید.' }); }
    }
    return send(res, 404, { error: 'not found' });
  }

  // استودیو (فقط با کلید مدیر)
  if (p.startsWith('/api/admin/')) {
    if (limited('admin', ip, 10, 600000)) return send(res, 429, { error: 'تلاش زیاد بود. ده دقیقه‌ی دیگر امتحان کنید.' });
    const given = Buffer.from(String(req.headers['x-admin-key'] || '')), want = Buffer.from(CFG.adminKey);
    if (given.length !== want.length || !crypto.timingSafeEqual(given, want)) { A('admin_fail'); note('admin', ip, 600000); return send(res, 403, { error: 'کلید استودیو درست نیست.' }); }
    if (p === '/api/admin/check') { A('admin_login'); return send(res, 200, { ok: true, open: Audit.openAlerts(), eleven: TTS.elevenReady(CFG.tts.eleven) }); }
    if (p === '/api/admin/log' && m === 'GET') return send(res, 200, { events: Audit.getLog({ limit: url.searchParams.get('limit'), type: url.searchParams.get('type'), uid: url.searchParams.get('uid'), q: url.searchParams.get('q') }), open: Audit.openAlerts() });
    if (p === '/api/admin/alerts' && m === 'GET') return send(res, 200, { alerts: Audit.getAlerts(), open: Audit.openAlerts() });
    const am = p.match(/^\/api\/admin\/alerts\/([a-z0-9]+)\/ack$/); if (am && m === 'POST') return send(res, 200, { ok: Audit.ackAlert(am[1]), open: Audit.openAlerts() });
    if (p === '/api/admin/visits' && m === 'GET') { const t0 = new Date(); t0.setHours(0, 0, 0, 0); const us = Object.values(db.users);
      return send(res, 200, Audit.getVisits({ users: us.length, newToday: us.filter(u => u.created >= t0.getTime()).length, paid: us.filter(u => u.paid).length, open: Audit.openAlerts() })); }
    if (p === '/api/admin/backups' && m === 'GET') return send(res, 200, { dir: 'data/backups', keep: BACKUP_KEEP, list: listBackups().reverse() });
    if (p === '/api/admin/backups' && m === 'POST') { await flushDb(); const ok = backupNow(true); A('backup'); return send(res, 200, { ok, list: listBackups().reverse() }); }
    if (p === '/api/admin/backup/download' && m === 'GET') {
      await flushDb(); A('backup_download');
      res.writeHead(200, { 'Content-Type': 'application/gzip', 'Content-Disposition': 'attachment; filename="mashgh-bazi-db-' + backupDay() + '.json.gz"', 'Cache-Control': 'no-store' });
      return res.end(require('zlib').gzipSync(Buffer.from(JSON.stringify(Object.assign({}, db, { sessions: {} })))));
    }
    if (p === '/api/admin/stats' && m === 'GET') return send(res, 200, { users: Object.keys(db.users).length, paid: Object.values(db.users).filter(u => u.paid).length,
      attempts: Object.values(db.attempts).reduce((s, a) => s + a.length, 0), matches: Object.values(db.users).reduce((s, u) => s + (u.matchLog || []).length, 0) });
    if (p === '/api/admin/eleven/status' && m === 'GET') { const pl = elevenPlan(url.searchParams.get('grade')); delete pl.pick;
      return send(res, 200, { ready: TTS.elevenReady(CFG.tts.eleven), running: ELV.running, ok: ELV.ok, fail: ELV.fail, total: ELV.total, chars: ELV.chars, error: ELV.error, plan: pl }); }
    if (p === '/api/admin/eleven/start' && m === 'POST') {
      if (!TTS.elevenReady(CFG.tts.eleven)) return send(res, 400, { error: 'کلید ElevenLabs تنظیم نشده. در config.json بخش tts.eleven.apiKey را بنویسید یا متغیر ELEVEN_API_KEY را بگذارید و برنامه را Restart کنید.' });
      if (ELV.running) return send(res, 409, { error: 'ساخت هم‌اکنون در جریان است.' });
      const b0 = await readJson(req).catch(() => ({})), pl = elevenPlan(b0 && b0.grade); if (!pl.pick.length) return send(res, 200, { started: false, message: 'چیزی برای ساختن نمانده؛ همه‌ی صداهای خودکار با ElevenLabs ساخته شده‌اند.' });
      A('eleven_start', { detail: pl.pick.length + ' جمله، ' + pl.willChars + ' نویسه' });
      elevenRun(pl.pick).catch(e => { console.error('elevenRun', e); ELV.running = false; ELV.error = e.message; });
      return send(res, 200, { started: true, total: pl.pick.length, chars: pl.willChars });
    }
    if (p === '/api/admin/eleven/stop' && m === 'POST') { ELV.stop = true; return send(res, 200, { ok: true }); }
    const tm = p.match(/^\/api\/admin\/tts\/([a-z0-9_]+)$/);
    if (tm && m === 'POST' && SAFE_ID.test(tm[1])) {
      const body = await readJson(req);
      const text = String(body.text || '').trim().slice(0, 400);
      if (!text) return send(res, 400, { error: 'متن خالی است.' });
      try {
        const audio = await TTS.synth(text, Object.assign({}, CFG.tts, body.voice ? { voice: body.voice } : {}));
        if (tm[1] === 'preview') return send(res, 200, audio, { 'Content-Type': 'audio/mpeg' });
        removeOld('voice', tm[1]);
        fs.writeFileSync(path.join(MEDIA, 'voice', tm[1] + '.mp3'), audio);
        if ((body.voice || CFG.tts.voice) === 'eleven') SRC[tm[1]] = 1; else delete SRC[tm[1]];
        saveSrc();
        return send(res, 200, { ok: true, url: `/media/voice/${tm[1]}.mp3?v=${Date.now()}`, bytes: audio.length });
      } catch (e) {
        console.error('TTS:', e.message);
        return send(res, 502, { error: 'ساخت صدا انجام نشد: ' + e.message + (e.status === 403 ? ' — احتمالاً سرور میزبان به سرویس صدای مایکروسافت راه ندارد. صدا را روی گوشی با فیلترشکن بسازید (node tools/make-voices.js) و با node tools/push-media.js به همین سایت بفرستید؛ یا صدا را در استودیو ضبط کنید.' : '') });
      }
    }
    const mm = p.match(/^\/api\/admin\/(voice|img)\/([a-z0-9_]+)$/);
    if (mm && SAFE_ID.test(mm[2])) {
      const dir = mm[1], id = mm[2];
      if (m === 'DELETE') { removeOld(dir, id); if (dir === 'voice') { delete SRC[id]; saveSrc(); } return send(res, 200, { ok: true }); }
      if (m === 'POST') {
        const type = String(req.headers['content-type'] || '').split(';')[0];
        const ext = { 'audio/webm': '.webm', 'audio/ogg': '.ogg', 'audio/mp4': '.m4a', 'audio/mpeg': '.mp3', 'audio/wav': '.wav', 'audio/x-wav': '.wav', 'audio/x-m4a': '.m4a', 'audio/aac': '.aac',
          'image/jpeg': '.jpg', 'image/png': '.png', 'image/webp': '.webp' }[type];
        if (!ext || (dir === 'voice') !== type.startsWith('audio/')) return send(res, 415, { error: 'نوع فایل پشتیبانی نمی‌شود.' });
        const buf = await readBody(req, 4 * 1024 * 1024);
        removeOld(dir, id);
        fs.writeFileSync(path.join(MEDIA, dir, id + ext), buf);
        if (dir === 'voice') { SRC[id] = 2; saveSrc(); }                  // آپلود/ضبط دستی؛ ساخت خودکار جایگزینش نمی‌کند
        return send(res, 200, { ok: true, url: `/media/${dir}/${id}${ext}?v=${Date.now()}` });
      }
    }
    return send(res, 404, { error: 'not found' });
  }
  return send(res, 404, { error: 'not found' });
}

/* فروشگاه: ستاره‌ی کل کم نمی‌شود؛ spent جدا نگه داشته می‌شود. owned فقط از راه /api/me/shop پر می‌شود (کلاینت نمی‌تواند خودش اضافه کند). */
const CHEST_MIN = 6, CHEST_STARS = 3, tehranDay = t => new Date(t + 210 * 60000).toISOString().slice(0, 10);
const ownedOf = u => (Array.isArray(u.owned) ? u.owned : []).filter(id => SHOP.BY_ID[id]);
const canWear = (u, id) => !!SHOP.BY_ID[id] && (SHOP.isFree(id) || ownedOf(u).indexOf(id) >= 0);
function stateOf(u) {
  const st = Object.assign({}, db.state[u.id] || {}, { stars: u.stars || 0, spent: u.spent || 0, owned: ownedOf(u), chest: u.chest || '' });
  const w = st.wear || {}, wear = {};
  SHOP.SLOTS.forEach(sl => { wear[sl.id] = w[sl.id] && canWear(u, w[sl.id]) && SHOP.BY_ID[w[sl.id]].slot === sl.id ? w[sl.id] : SHOP.DEFAULT_WEAR[sl.id]; });
  st.wear = wear; st.fam = famOf(u); return st;
}
/* هدف پدر و مادر با پیشرفتِ به‌روز (اگر شاخص به هدف رسیده، زمان رسیدن ثبت می‌شود) */
function famOf(u) {
  const f = FAM.refresh(FAM.clean(u.fam), FAM.metrics(db.state[u.id], u.stars), Date.now());
  if (f.goal && f.goal.done && !(u.fam && u.fam.goal && u.fam.goal.done)) { u.fam = f; persist(); }
  return f;
}
function shopBuy(u, id) {
  const key = typeof id === 'string' && /^[a-z_]{1,30}$/.test(id) ? id : '', it = key ? SHOP.BY_ID[key] : null;   /* شناسه فقط حروف کوچک؛ جلوی __proto__ و مانند آن */
  if (!it) return { code: 400, body: { error: 'این جایزه وجود ندارد.' } };
  const owned = ownedOf(u);
  if (it.price === 0 || owned.indexOf(it.id) >= 0) return { code: 200, body: { ok: true, already: true, stars: u.stars || 0, spent: u.spent || 0, owned: owned } };
  const wallet = (u.stars || 0) - (u.spent || 0);
  if (wallet < it.price) return { code: 409, body: { error: 'ستاره‌ی کافی نداری.', stars: u.stars || 0, spent: u.spent || 0, owned: owned } };
  u.spent = (u.spent || 0) + it.price; u.owned = owned.concat(it.id); persist();
  return { code: 200, body: { ok: true, stars: u.stars || 0, spent: u.spent, owned: u.owned } };
}
function cleanAttempt(a, grade) {
  if (!a || typeof a !== 'object' || !Object.prototype.hasOwnProperty.call(CATALOG.GAMES, a.g)) return null;
  if (grade && gradeOfGame(a.g) !== grade) return null;
  return { g: a.g, item: String(a.item || '').slice(0, 40), ok: !!a.ok, first: !!a.first, ms: Math.max(0, Math.min(+a.ms || 0, 600000)), t: Math.min(+a.t || Date.now(), Date.now()) };
}
/* ستاره‌ها روی سرور حساب می‌شوند: هر جواب درستِ بار اول یک ستاره */
/* کنترل معقول بودن پاسخ‌ها: ستاره‌ی «بار اولِ درست» فقط وقتی شمرده می‌شود که
   ۱) پاسخ تکراری نباشد (همان بازی+آیتم+زمان)، ۲) زمان پاسخ کمتر از ۲۵۰ میلی‌ثانیه نباشد،
   ۳) زمان ثبت در آینده یا بیش از ۴۵ روز قبل نباشد، ۴) در هر روز از ۳۰۰ ستاره بیشتر نشود.
   پاسخ ردشده ذخیره می‌شود ولی first=false تا گزارش هم باد نکند. (کلاینت قابل اعتماد کامل نیست؛ این‌ها فقط جلوی انبوه‌سازی را می‌گیرند.) */
const STAR_DAY_CAP = 300, dayOf = t => new Date(t).toISOString().slice(0, 10);
function vetAttempts(existing, arr) {
  const keys = new Set(), perDay = {}, now = Date.now();
  existing.forEach(a => { if (a.first && a.ok) { keys.add(a.g + '|' + a.item + '|' + a.t); const d = dayOf(a.t); perDay[d] = (perDay[d] || 0) + 1; } });
  arr.forEach(a => {
    if (!(a.first && a.ok)) return;
    const k = a.g + '|' + a.item + '|' + a.t, d = dayOf(a.t);
    if (keys.has(k) || a.ms < 250 || a.t > now + 60000 || a.t < now - 45 * 864e5 || (perDay[d] || 0) >= STAR_DAY_CAP) { a.first = false; return; }
    keys.add(k); perDay[d] = (perDay[d] || 0) + 1;
  });
  return arr;
}
function addAttempts(u, raw) {
  const arr = vetAttempts(db.attempts[u.id] || [], raw.map(a => cleanAttempt(a, u.grade)).filter(Boolean));
  Audit.attempts(u, arr);
  const list = db.attempts[u.id] = (db.attempts[u.id] || []).concat(arr);
  if (list.length > 20000) db.attempts[u.id] = list.slice(-20000);
  u.stars = (u.stars || 0) + arr.filter(a => a.first && a.ok).length;
  persist(); return arr.length;
}
function cleanState(s) {
  const out = { plays: {}, best: {}, seen: {}, days: {}, mascot: String(s.mascot || '').replace(/[^a-z]/g, '').slice(0, 20), wear: {} };
  /* چیزی که پوشیده: فقط شناسه‌ی معتبر همان جایگاه؛ مالکیت در stateOf بررسی می‌شود */
  const w = s.wear && typeof s.wear === 'object' ? s.wear : {};
  SHOP.SLOTS.forEach(sl => { const v = String(w[sl.id] || ''); if (SHOP.BY_ID[v] && SHOP.BY_ID[v].slot === sl.id) out.wear[sl.id] = v; });
  let dn = 0; for (const k in (s.days || {})) { if (++dn > 120) break; if (/^\d{4}-\d{2}-\d{2}$/.test(k)) out.days[k] = Math.max(0, Math.min(500, +s.days[k] || 0)); }
  const has = k => Object.prototype.hasOwnProperty.call(CATALOG.GAMES, k);
  for (const k in (s.plays || {})) if (has(k)) out.plays[k] = Math.max(0, Math.min(10000, +s.plays[k] || 0));
  for (const k in (s.best || {})) if (has(k)) out.best[k] = Math.max(0, Math.min(50, +s.best[k] || 0));
  let n = 0;
  for (const k in (s.seen || {})) { if (++n > 3000) break; if (/^[a-z0-9_:]{1,40}$/i.test(k) && Array.isArray(s.seen[k])) out.seen[k] = s.seen[k].slice(0, 200).map(Number).filter(v => v >= 0 && v < 1000); }
  /* ۱.۱۹.۰: مجموعه‌ی موجودات، تخم جادویی و رویدادهای فصلی */
  out.coll = {}; out.ev = {}; out.egg = { p: 0, ready: 0 };
  let cn = 0; for (const k in (s.coll || {})) { if (++cn > 60) break; if (/^[a-z0-9_]{1,24}$/.test(k)) out.coll[k] = Math.max(0, Math.min(999, +s.coll[k] || 0)); }
  cn = 0; for (const k in (s.ev || {})) { if (++cn > 40) break; if (/^[a-z]{2,12}_\d{4}$/.test(k) && s.ev[k] && typeof s.ev[k] === 'object') out.ev[k] = { n: Math.max(0, Math.min(999, +s.ev[k].n || 0)), done: !!s.ev[k].done }; }
  if (s.egg && typeof s.egg === 'object') out.egg = { p: Math.max(0, Math.min(9, +s.egg.p || 0)), ready: Math.max(0, Math.min(20, +s.egg.ready || 0)) };
  /* ۱.۲۰.۰: رشد حیوون خونگی (فقط شناسه‌ی حیوانِ فروشگاه) و شمارش بلندخوانی */
  out.pet = FAM.cleanPet(s.pet, k => !!SHOP.BY_ID[k] && SHOP.BY_ID[k].slot === 'pet');
  out.rd = FAM.cleanRead(s.rd);
  out.adv = ADV.clean(s.adv);
  return out;
}

/* صفحه‌های پرداخت */
function payPage(title, body) {
  return `<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>${title}</title><link rel="stylesheet" href="/css/app.css"></head><body><div id="app" dir="rtl"><section class="screen"><h2>${title}</h2><div class="board" style="margin-top:16px">${body}</div></section></div></body></html>`;
}
const HTML = { 'Content-Type': 'text/html; charset=utf-8' };
async function payRoutes(req, res, url) {
  const pid = url.searchParams.get('pid') || '';
  const pay = /^[a-f0-9]{16}$/.test(pid) ? db.payments[pid] : null;
  if (!pay) return send(res, 404, payPage('پرداخت پیدا نشد', '<p>این پرداخت وجود ندارد.</p><a class="next" href="/">برگشت</a>'), HTML);
  if (url.pathname === '/pay/dev') {
    if (payMode() !== 'dev') return send(res, 403, payPage('غیرفعال', '<p>پرداخت آزمایشی روی این سایت بسته است.</p>'), HTML);
    const me = currentUser(req);
    if (!me || me.id !== pay.uid) return send(res, 403, payPage('اجازه ندارید', '<p>اول با همان حساب وارد شوید.</p><a class="next" href="/">برگشت</a>'), HTML);
    if (req.method === 'POST') { markPaid(pay, 'DEV-' + pid); res.writeHead(303, { Location: '/#report' }); return res.end(); }
    return send(res, 200, payPage('پرداخت آزمایشی', `<p>درگاه واقعی هنوز تنظیم نشده (کد پذیرنده‌ی زرین‌پال در config.json خالی است). این صفحه فقط برای آزمایش است و پولی جابه‌جا نمی‌شود.</p><p>مبلغ: ${(pay.amountRial / 10).toLocaleString('fa-IR')} تومان</p><form method="post"><button class="next">پرداخت آزمایشی موفق</button></form><a class="ghost" href="/">انصراف</a>`), HTML);
  }
  if (url.pathname === '/pay/callback') {
    const status = url.searchParams.get('Status'), authority = url.searchParams.get('Authority');
    if (status === 'OK' && authority && authority === pay.authority && pay.status !== 'paid') {
      try { const v = await zarinpalVerify(pay.amountRial, authority); if (v.ok) { markPaid(pay, v.ref); res.writeHead(303, { Location: '/#report' }); return res.end(); } pay.status = 'failed'; persist(); }
      catch (e) { console.error(e); }
    }
    if (pay.status === 'paid') { res.writeHead(303, { Location: '/#report' }); return res.end(); }
    return send(res, 200, payPage('پرداخت انجام نشد', '<p>پرداخت کامل نشد. اگر پولی از حسابتان کم شده، طبق قانون تا ۷۲ ساعت برمی‌گردد.</p><a class="next" href="/#report">برگشت</a>'), HTML);
  }
  return send(res, 404, 'not found');
}

/* فایل‌های ثابت */
const textCache = new Map();   // مسیر → { mtime, buf }
async function readCached(file, st) {
  const c = textCache.get(file);
  if (c && c.mtime === st.mtimeMs) return c.buf;
  const buf = await fsp.readFile(file); textCache.set(file, { mtime: st.mtimeMs, buf }); return buf;
}
/* فایل‌های بزرگ دنیای سه‌بعدی (wasm / pck) یک‌بار فشرده و در حافظه نگه داشته می‌شوند تا دانلود اول سبک‌تر شود */
const bigZ = new Map();
function bigGzip(file, st) {
  const key = file + ':' + st.size + ':' + Math.round(st.mtimeMs);
  let p = bigZ.get(key);
  if (!p) {
    p = fsp.readFile(file).then(buf => new Promise((res, rej) => zlib.gzip(buf, { level: 6 }, (e, out) => e ? rej(e) : res(out))));
    bigZ.clear(); bigZ.set(key, p);
  }
  return p;
}
function warmBig() {
  ['/world3d/index.wasm', '/world3d/index.pck'].forEach(r => {
    const f = path.join(PUBLIC, r);
    fsp.stat(f).then(st => bigGzip(f, st)).catch(() => {});
  });
}
async function serveStatic(req, res, url) {
  let rel = safeDecode(url.pathname);
  if (rel == null || rel.includes('\0')) return send(res, 400, 'bad request', { 'Content-Type': 'text/plain; charset=utf-8' });
  let base = PUBLIC;
  if (rel.startsWith('/media/')) { base = MEDIA; rel = rel.slice(6); }
  const isHome = rel === '/' || rel === '' || rel === '/index.html';
  if (isHome) rel = '/index.html';
  if (rel === '/world3d' || rel === '/world3d/') rel = '/world3d/index.html';
  if (rel === '/studio') rel = '/studio.html';
  if (rel === '/admin') rel = '/admin.html';
  const file = path.normalize(path.join(base, rel));
  if (!file.startsWith(base + path.sep)) return send(res, 403, 'forbidden', { 'Content-Type': 'text/plain; charset=utf-8' });
  let st; try { st = await fsp.stat(file); } catch (e) { st = null; }
  if (!st || !st.isFile()) { const b = baseUrl(req); return sendText(req, res, 404, Buffer.from(SEO.notFound(b)), HTML['Content-Type']); }
  const ext = path.extname(file).toLowerCase(), type = MIME[ext] || 'application/octet-stream';
  if (COMPRESSIBLE.has(ext) && st.size < 4 * 1024 * 1024) {
    let buf = await readCached(file, st);
    const extra = {};
    if (isHome) buf = Buffer.from(SEO.home(buf.toString('utf8'), baseUrl(req)));
    if (rel === '/studio.html' || rel === '/admin.html') extra['X-Robots-Tag'] = 'noindex';
    return sendText(req, res, 200, buf, type, extra);
  }
  if ((ext === '.wasm' || ext === '.pck') && /\bgzip\b/.test(String(req.headers['accept-encoding'] || '')) && req.method !== 'HEAD') {
    const etag = `"${st.size.toString(36)}-${Math.round(st.mtimeMs).toString(36)}-z"`;
    const hz = { 'Content-Type': type, ETag: etag, Vary: 'Accept-Encoding', 'Cache-Control': 'no-cache', 'Content-Encoding': 'gzip', 'X-Content-Type-Options': 'nosniff' };
    if (req.headers['if-none-match'] === etag) { res.writeHead(304, hz); return res.end(); }
    try { const body = await bigGzip(file, st); hz['Content-Length'] = body.length; res.writeHead(200, hz); return res.end(body); } catch (e) { /* برگشت به ارسال بدون فشرده‌سازی */ }
  }
  const longCache = ext === '.woff2' || base === MEDIA || rel.startsWith('/img/');
  const etag = `"${st.size.toString(36)}-${Math.round(st.mtimeMs).toString(36)}"`;
  const h = { 'Content-Type': type, 'Content-Length': st.size, ETag: etag, 'Cache-Control': longCache ? 'public, max-age=2592000' : 'no-cache', 'X-Content-Type-Options': 'nosniff' };
  if (req.headers['if-none-match'] === etag) { delete h['Content-Length']; res.writeHead(304, h); return res.end(); }
  res.writeHead(200, h);
  if (req.method === 'HEAD') return res.end();
  fs.createReadStream(file).on('error', () => res.destroy()).pipe(res);
}

/* Service Worker: نسخه و فهرست فایل‌ها از روی پوشه‌ی public ساخته می‌شود تا هیچ‌وقت کهنه نماند */
let swCache = { at: 0, body: '' };
function listFiles(dir, rel, out) {
  let names = []; try { names = fs.readdirSync(dir); } catch (e) { return out; }
  names.forEach(n => { const f = path.join(dir, n), r = rel + '/' + n; let st; try { st = fs.statSync(f); } catch (e) { return; }
    if (st.isDirectory()) listFiles(f, r, out); else out.push({ p: r, t: Math.round(st.mtimeMs), s: st.size }); });
  return out;
}
function swBody() {
  if (Date.now() - swCache.at < 60000 && swCache.body) return swCache.body;
  const tpl = fs.readFileSync(path.join(PUBLIC, 'sw.template.js'), 'utf8');
  const js = listFiles(path.join(PUBLIC, 'js'), '/js', []).filter(x => /\.js$/.test(x.p)), css = listFiles(path.join(PUBLIC, 'css'), '/css', []),
    fonts = listFiles(path.join(PUBLIC, 'fonts'), '/fonts', []).filter(x => /\.woff2$/.test(x.p)), audio = listFiles(path.join(PUBLIC, 'audio'), '/audio', []),
    img = listFiles(path.join(PUBLIC, 'img'), '/img', []).filter(x => /\.(png|jpe?g|webp|svg|gif)$/i.test(x.p) && x.p !== '/img/og.jpg');
  const core = ['/', '/manifest.webmanifest', '/img/icon-192.png', '/img/apple-touch-icon.png'].concat(js.map(x => x.p), css.map(x => x.p), fonts.map(x => x.p), audio.map(x => x.p));
  const all = js.concat(css, fonts, audio, img);
  const ver = require('./package.json').version + '-' + crypto.createHash('sha1').update(all.map(x => x.p + x.t + x.s).join('|')).digest('hex').slice(0, 8);
  swCache = { at: Date.now(), body: tpl.replace('__VERSION__', ver).replace('__CORE__', JSON.stringify(core)).replace('__WARM__', JSON.stringify(img.map(x => x.p))) };
  return swCache.body;
}

const server = http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://x');
    if (url.pathname === '/.well-known/assetlinks.json') {
      if (!CFG.twa.sha256.length) return send(res, 404, 'not found', { 'Content-Type': 'text/plain; charset=utf-8' });
      const tgt = ns => ({ namespace: ns, package_name: CFG.twa.package, sha256_cert_fingerprints: CFG.twa.sha256 });
      /* دومی را اعتبارسنج کافه‌بازار برای برنامه‌های TWA می‌خواهد (namespace = cafebazaar_twa، relation = check_validation) */
      return send(res, 200, [{ relation: ['delegate_permission/common.handle_all_urls'], target: tgt('android_app') }, { relation: ['check_validation'], target: tgt('cafebazaar_twa') }], { 'Cache-Control': 'public, max-age=3600' });
    }
    if (url.pathname === '/sw.js' && (req.method === 'GET' || req.method === 'HEAD')) {
      res.writeHead(200, { 'Content-Type': 'text/javascript; charset=utf-8', 'Cache-Control': 'no-cache', 'Service-Worker-Allowed': '/', 'X-Content-Type-Options': 'nosniff' });
      return res.end(req.method === 'HEAD' ? undefined : swBody());
    }
    Audit.visit(req, url, clientIp(req));
    /* درخواست‌های تغییردهنده فقط از خود سایت: اگر Origin فرستاده شده باید با آدرس سایت یکی باشد */
    if (CFG.originCheck && req.method !== 'GET' && req.method !== 'HEAD' && req.headers.origin && !originOk(req)) return send(res, 403, { error: 'درخواست از مبدأ نامعتبر.' });
    if (url.pathname.startsWith('/api/')) return await api(req, res, url);
    if (url.pathname.startsWith('/pay/')) return CFG.fullReport ? await payRoutes(req, res, url) : send(res, 404, 'not found');
    if (req.method !== 'GET' && req.method !== 'HEAD') return send(res, 405, 'method not allowed');
    if (url.pathname === '/healthz') return send(res, 200, { ok: true });
    if (url.pathname === '/privacy') return sendText(req, res, 200, Buffer.from(SEO.privacyPage(baseUrl(req), CFG.contact)), HTML['Content-Type']);
    if (url.pathname === '/worksheet') return sendText(req, res, 200, Buffer.from(require('./lib/worksheet.js').page(baseUrl(req), Object.fromEntries(url.searchParams))), HTML['Content-Type'], { 'Cache-Control': 'no-store' });
    if (url.pathname === '/robots.txt') return sendText(req, res, 200, Buffer.from(SEO.robots(baseUrl(req))), MIME['.txt']);
    if (url.pathname === '/sitemap.xml') return sendText(req, res, 200, Buffer.from(SEO.sitemap(baseUrl(req))), MIME['.xml']);
    if (url.pathname.startsWith('/grade/') || url.pathname.startsWith('/lesson/')) { const r = SEO.route(url.pathname, baseUrl(req)); if (r) return sendText(req, res, r.code, Buffer.from(r.html), HTML['Content-Type']); }
    return await serveStatic(req, res, url);
  } catch (e) {
    if ([400, 413, 415].includes(e.code)) return send(res, e.code, { error: e.code === 413 ? 'فایل خیلی بزرگ است.' : 'درخواست نامعتبر.' });
    console.error(e);
    if (!res.headersSent) send(res, 500, { error: 'خطای سرور' });
  }
});
server.on('error', e => { fatal(new Error(`سرور روی پورت ${CFG.port} بالا نیامد (${e.code}). اگر پورت اشغال است، پورت دیگری بدهید یا برنامه‌ی قبلی را ببندید.\n` + e.message)); process.exit(1); });
const listenArgs = typeof CFG.port === 'number' ? [CFG.port, CFG.host] : [CFG.port];
server.listen(...listenArgs, () => {
  console.log(`مشق‌بازی روشن شد:  http://localhost:${CFG.port}`);
  console.log(`استودیوی صدا و عکس:  http://localhost:${CFG.port}/studio`);
  console.log(!CFG.fullReport ? 'ارزیابی کامل (پولی): غیرفعال' : `پرداخت: ${{ zarinpal: 'زرین‌پال' + (CFG.zarinpal.sandbox ? ' (آزمایشی)' : ''), dev: 'آزمایشی (بدون درگاه واقعی)', off: 'غیرفعال (publicUrl تنظیم شده ولی کد زرین‌پال نه)' }[payMode()]}`);
  setTimeout(warmBig, 3000).unref();
  console.log(`پیامک: ${SMS.enabled() ? CFG.sms.provider : 'غیرفعال (ثبت‌نام بدون کد تأیید، بازیابی رمز بسته)'}`);
});

module.exports = { server };
